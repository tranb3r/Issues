﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCompany("MauiAppBabel103")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0+6ae3f2bf9fef89cb78c00d48819d336bb56085d8")]
[assembly: AssemblyProduct("MauiAppBabel103")]
[assembly: AssemblyTitle("MauiAppBabel103")]
[assembly: TargetPlatform("Android34.0")]
[assembly: SupportedOSPlatform("Android21.0")]
[module: RefSafetyRules(11)]
