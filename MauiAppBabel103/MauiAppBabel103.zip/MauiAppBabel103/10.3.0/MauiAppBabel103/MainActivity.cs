﻿using System;
using Android.App;
using Microsoft.Maui;

namespace MauiAppBabel103
{
	// Token: 0x02000003 RID: 3
	[Activity(Theme = "@style/Maui.SplashTheme", MainLauncher = true, ConfigurationChanges = 8064)]
	public class MainActivity : MauiAppCompatActivity
	{
	}
}
