﻿using System;
using _Microsoft.Android.Resource.Designer;

namespace MauiAppBabel103
{
	// Token: 0x02000005 RID: 5
	public class Resource : ResourceConstant
	{
	}
}
