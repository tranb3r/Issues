﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;

namespace MauiAppBabel103
{
	// Token: 0x02000002 RID: 2
	public static class MauiProgram
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002048 File Offset: 0x00000248
		public static MauiApp CreateMauiApp()
		{
			MauiAppBuilder mauiAppBuilder = MauiApp.CreateBuilder(true);
			AppHostBuilderExtensions.UseMauiApp<_>(mauiAppBuilder);
			mauiAppBuilder.Services.AddTransient<m_, mm>();
			return mauiAppBuilder.Build();
		}
	}
}
